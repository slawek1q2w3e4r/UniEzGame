#include <pybind11/pybind11.h>
#include <SDL.h>
#include "iostream"

int dodaj(int a, int b) {
    return a + b;
}

// Funkcja do tworzenia okna i ustawiania koloru t�a
void create_window(int width, int height, int r, int g, int b, const std::string& title) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "Nie mo�na zainicjowa� SDL: " << SDL_GetError() << std::endl;
        return;
    }

    SDL_Window* window = SDL_CreateWindow(
        title.c_str(),                // Tytu� okna
        SDL_WINDOWPOS_CENTERED,          // Pozycja X
        SDL_WINDOWPOS_CENTERED,          // Pozycja Y
        width,                           // Szeroko�� okna
        height,                          // Wysoko�� okna
        SDL_WINDOW_SHOWN                 // Flagi okna
    );

    if (!window) {
        std::cerr << "Nie mo�na stworzy� okna: " << SDL_GetError() << std::endl;
        SDL_Quit();
        return;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        std::cerr << "Nie mo�na stworzy� renderera: " << SDL_GetError() << std::endl;
        SDL_DestroyWindow(window);
        SDL_Quit();
        return;
    }

    // Ustaw kolor t�a (r, g, b) i wyczy�� ekran
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);  // Ustaw kolor z warto�ci RGB
    SDL_RenderClear(renderer);  // Wyczy�� ekran wype�niaj�c go kolorem

    SDL_RenderPresent(renderer);  // Wy�wietl zmiany na ekranie

    SDL_Delay(3000);  // Czekaj 3 sekundy zanim okno si� zamknie

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}

PYBIND11_MODULE(unigame, m) {
    m.doc() = "Prosta biblioteka C++ dla Pythona";  // Opis modu�u
    m.def("dodaj", &dodaj, "Funkcja dodaj�ca dwie liczby");
    m.def("create_window", &create_window, "Funkcja tworz�ca okno", pybind11::arg("width"), pybind11::arg("height"), pybind11::arg("r"), pybind11::arg("g"), pybind11::arg("b"), pybind11::arg("title"));
}
