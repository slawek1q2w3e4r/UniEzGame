from setuptools import setup, Extension
import os
import pybind11

# ╔════════════════════════════════════════════════════════════╗
# ║                      To make the package work,                               ║
# ║                      you need to download SDL2                               ║
# ║                      and complete the paths below,                           ║ 
# ║                      so that will everything works correctly.                ║
# ╚════════════════════════════════════════════════════════════╝


# Ścieżki do SDL2
SDL2_INCLUDE_DIR = r'D:\dev\SDL2\include'
SDL2_LIB_DIR = r'D:\dev\SDL2\lib\x64'
SDL2_DLL = r'D:\dev\SDL2\lib\x64\SDL2.dll'

module_name = 'unigame'

# Tworzenie rozszerzenia
unigame_module = Extension(
    module_name,
    sources=['mylib.cpp'],
    include_dirs=[SDL2_INCLUDE_DIR, pybind11.get_include()],  # Dodaj pybind11
    library_dirs=[SDL2_LIB_DIR],      # Ścieżka do bibliotek SDL2
    libraries=['SDL2', 'SDL2main'],   # Nazwy bibliotek SDL2
)

setup(
    name=module_name,
    version='0.1',
    description='Unigame - Python C++ bindings using pybind11',
    ext_modules=[unigame_module],
)

# Kopiowanie pliku SDL2.dll (jeśli to potrzebne)
if os.path.exists(SDL2_DLL):
    import shutil
    shutil.copy(SDL2_DLL, os.path.join(os.path.dirname(__file__), 'build'))